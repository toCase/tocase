#!/bin/sh
cd "$(dirname "$(0)")/usr"
EXEC="toCase" #$(grep -m 1 -r Exec= ../*.desktop | cut -d "=" -f 2 | cut -d % -f 1)
export LD_LIBRARY_PATH="./lib:${LD_LIBRARY_PATH}" 
PATH="./bin/" exec $EXEC $@ :${PATH}
